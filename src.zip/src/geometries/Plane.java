package geometries;

import primitives.Point;
import primitives.Ray;
import primitives.Vector;

import java.util.List;

import static primitives.Util.isZero;

/**
 * The `Plane` class represents a plane in 3D space.
 * It is defined by a point on the plane and a normal vector.
 */
public class Plane extends Geometry {

    /**
     * A point on the plane.
     */
    protected final Point q;
    /**
     * The normal vector to the plane.
     */
    protected final Vector normal;

    /**
     * Constructs a `Plane` with the specified point and normal vector.
     *
     * @param point  the point on the plane
     * @param normal the normal vector to the plane
     */
    public Plane(Point point, Vector normal) {
        this.q = point;
        this.normal = normal.normalize();
    }

    /**
     * Constructs a `Plane` with three points on the plane.
     * The normal vector is calculated from these points.
     *
     * @param point1 the first point on the plane
     * @param point2 the second point on the plane
     * @param point3 the third point on the plane
     */
    public Plane(Point point1, Point point2, Point point3) {
        normal = point2.subtract(point1).crossProduct(point3.subtract(point1)).normalize();
        q = point1;
    }

    /**
     * Returns the normal vector to the plane at the given point.
     *
     * @param p the point on the plane
     * @return the normal vector at the given point
     */
    @Override
    public Vector getNormal(Point p) {
        return normal;
    }

    public List<Point> findIntersections(Ray ray) {

        Vector v = ray.getDirection();
        Point p0 = ray.getP0();
        //BVA 6
        if(p0.equals(q)) {
            return null;
        }
        Vector q_p0 =q.subtract(p0);
         //BVA 7+4
        if(isZero( normal.dotProduct(q_p0))) {
            return null;
        }

        //BVA 1 2
        if( normal.dotProduct(v) == 0)
            return null;

        double nv = normal.dotProduct(v);
       // double t = (v.dotProduct(q_p0) / nv);
        double t = (normal.dotProduct(q_p0) / nv);
        if(t < 0||t==(0)) {
            return null;
        }
        return List.of(ray.getPoint(t));

    }
}
