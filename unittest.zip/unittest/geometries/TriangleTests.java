package geometries;
import primitives.Point;

import org.junit.jupiter.api.Test;
import primitives.Ray;
import primitives.Vector;

import static org.junit.jupiter.api.Assertions.*;
import geometries.Triangle;
/**
 * Unit tests for the {@link Triangle} class.
 * <p>
 * This class contains a series of tests for the methods implemented in the {@link Triangle} class,
 * ensuring that the triangle operations behave as expected. The tests include operations such as
 * normal calculation.
 * </p>
 */
class TriangleTests {
    private final Vector v1 = new Vector(0, 0, -1);
    private final Vector v2 = new Vector(0, 0, 1);
    private final Point p1 = new Point(0, 0, 1);
    private final Point p2 = new Point(0, 1, 0);
    private final Point p3 = new Point(1, 0, 0);
    private final Triangle triangle = new Triangle(new Point(1, 1, 0), p3, p2);
    /**
     * Default constructor for {@code TriangleTests}.
     * <p>
     * Initializes the test class without any specific setup or initialization.
     * </p>
     */
    public TriangleTests() {
        // Default constructor, no initialization or actions
    }

    /**
     * Test method for {@link Triangle#getNormal(Point)}.
     * <p>
     * Verifies that the {@code getNormal()} method correctly computes the normal vector at a point on the surface of the triangle.
     * </p>
     */
    @Test
    void testGetNormal() {
        // ============ Equivalence Partitions Tests ==============
        // Checking if the normal is correctly calculated for a valid triangle
        Vector expectedNormal = new Vector(1, 1, 1).normalize();
        assertEquals(expectedNormal, new Triangle(new Point(1, 0, 0), new Point(0, 1, 0), new Point(0, 0, 1)).getNormal(new Point(0, 0, 0)), "ERROR: Triangle getNormal() does not work correctly");
    }
    /**
     * Test method for {@link Triangle#Triangle(Point, Point, Point)}.
     */
    @Test
    void testFindIntersections() {
        // ============ Equivalence Partitions Tests ==============
        // TC01: the intersection point is inside the triangle
        assertEquals(1, triangle.findIntersections(
                        new Ray(new Point(1.8, 1.8, 1), new Vector(-1, -1, -1))).size(),
                "Failed to find the intersection point when the intersection point is inside the triangle");

        // TC02: the intersection point is outside the triangle and against an edge
        assertNull(triangle.findIntersections(
                        new Ray(new Point(0.5, 2, 1), v1)),
                "Failed to find the intersection point when the intersection point is outside the triangle and against an edge");

        // TC03: the intersection point is outside the triangle and against a vertex
        assertNull(triangle.findIntersections(
                        new Ray(new Point(2, 2, 1), v1)),
                "Failed to find the intersection point when the intersection point is outside the triangle and against an edge");

        // ================= Boundary Values Tests =================
        // TC04: the intersection point is on the edge of the triangle
        assertNull(triangle.findIntersections(
                        new Ray(new Point(0.5, 1, -1), v2)),
                "Failed to find the intersection point when the intersection point is on the edge of the triangle");

        // TC05: the intersection point is on the vertex of the triangle
        assertNull(triangle.findIntersections(
                        new Ray(new Point(1, 1, 1), new Vector(0, 0, -1))),
                "Failed to find the intersection point when the intersection point is on the vertex of the triangle");

        // TC06: the intersection point is outside the triangle but in the path of the edge
        assertNull(triangle.findIntersections(
                        new Ray(new Point(2, 1, -1), v2)),
                "Failed to find the intersection point when the intersection point is outside the triangle but in the path of the edge");

        // ================= external Tests =================
        // TC07: the triangle is in an angle
        Triangle triangle2 = new Triangle(p3, p2, p1);
        assertEquals(1, triangle2.findIntersections(
                        new Ray(new Point(-1, -1, -1), new Vector(1, 1, 1))).size(),
                "Failed to find the intersection point when the intersection point is inside the triangle");

    }

}